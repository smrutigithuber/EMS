package com.ems.dao;

import java.util.List;

import com.ems.model.Employee;



public interface EmployeeDao {
	 public  List<Employee> getAllEmployee();
	  public void insertEmployee(Employee employee);
	  public void deleteEmployee(int employee_id);
	  public Employee editEmployee(int employee_id);
	  public void updateEmployee(Employee employee);
}
