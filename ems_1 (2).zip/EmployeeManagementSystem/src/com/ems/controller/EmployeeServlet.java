package com.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.daoimpl.EmployeeDaoimpl;
import com.ems.model.Employee;





@WebServlet("/")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    EmployeeDaoimpl edi;
    @Override
 public void init() throws ServletException {
 	edi=new EmployeeDaoimpl();
 }
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		    String action = req.getServletPath();
		    switch(action) {
		    case "/list":
		    	getAllEmployee(req , resp);
				break;
		    case "/insert":
				insertEmployee(req, resp);
				break;
		    case "/delete":
				deleteEmployee(req, resp);
				break;
			case "/edit":
				editEmployee(req, resp);
				break;
			case "/update":
				updateEmployee(req, resp);
				break;
		    case "/register":
				registerEmployee(req, resp);
				break;
		    case "/loginForm":
				AdminLogin(req, resp);
				break;
		    case "/signupform":
				AdminSignup(req, resp);
				break;		    	
		    }
	}

	private void AdminLogin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
req.getRequestDispatcher("login.jsp").forward(req, resp);
		
	}
	private void AdminSignup(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("signup.jsp").forward(req, resp);
		
		
	}
	private void insertEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		 String name= req.getParameter("name");
		 String job_title=req.getParameter("job_title");
		 String department = req.getParameter("department");
		 String contact_details = req.getParameter("contact_details");
		  Employee insertEmployee= new Employee(name,job_title,department,contact_details);
		  edi.insertEmployee(insertEmployee);
		  resp.sendRedirect("list");
		
	}
	private void updateEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		 int employee_id=Integer.parseInt(req.getParameter("employee_id"));
		 String name= req.getParameter("name");
		 String  job_title=req.getParameter("job_title");
		 String department = req.getParameter("department");
		 String contact_details = req.getParameter("contact_details");		  
		 Employee updateEmployee= new Employee(name,job_title,department,contact_details);
		 edi.updateEmployee(updateEmployee);
		 resp.sendRedirect("list");
		
	}
	private void editEmployee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int employee_id = Integer.parseInt(req.getParameter("employee_id"));
		Employee editEmployee=edi.editEmployee(employee_id);
		req.setAttribute("employee1", editEmployee);
		req.getRequestDispatcher("updateForm.jsp").forward(req, resp);
		
	}
	private void deleteEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		int employee_id=Integer.parseInt(req.getParameter("employee_id"));
		edi.deleteEmployee(employee_id);
		resp.sendRedirect("list");
		
	}
	private void registerEmployee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("employeeRegister.jsp").forward(req, resp);
		
	}

	private void getAllEmployee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Employee> employee= edi.getAllEmployee();
		req.setAttribute("employee", employee);
		req.getRequestDispatcher("employee.jsp").forward(req, resp);
		
	}
	

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doGet(req, resp);
	}

}
	
