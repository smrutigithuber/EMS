package com.ems.model;

public class Employee {

	protected int  employee_id;
	protected String name;
	protected String job_title;
	protected String department;
	protected String contact_details;
	
	
	
	public Employee( String name, String job_title, String department, String contact_details) {
		super();
		this.name = name;
		this.job_title = job_title;
		this.department = department;
		this.contact_details = contact_details;
	}



	public Employee(int employee_id, String name, String job_title, String department, String contact_details) {
		super();
		this.employee_id = employee_id;
		this.name = name;
		this.job_title = job_title;
		this.department = department;
		this.contact_details = contact_details;
	}

	
	
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob_title() {
		return job_title;
	}
	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getContact_details() {
		return contact_details;
	}
	public void setContact_details(String contact_details) {
		this.contact_details = contact_details;
	}
}
