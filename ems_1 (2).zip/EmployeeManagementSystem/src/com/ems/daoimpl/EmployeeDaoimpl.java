package com.ems.daoimpl;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ems.dao.EmployeeDao;
import com.ems.model.Employee;




public class EmployeeDaoimpl implements EmployeeDao {
	
	
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/empl";

	static final String USER = "root";
	static final String PASS = "root";

	static final String GETALLINFO = "Select * from employee";
	static final String INSERTINFO = "insert into employee(name,job_title,department,contact_details) values(?,?,?,?)";
	static final String DELETEINFO = "delete from employee where employee_id=?;";
	static final String EDITBYID = "select * from employee where employee_id=?;";
	static final String UPDATEINFO = "update employee set name=?,job_title= ?, department =?, contact_details =? where employee_id= ?";
    
	public Connection getCon()  {
		Connection con=null;
		  try {
			  Class.forName(JDBC_DRIVER);
			  con=DriverManager.getConnection(DB_URL, USER, PASS);
		  }catch(SQLException | ClassNotFoundException e) {}
		
		return con;
	}
	
	
	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> allEmployee= new ArrayList<>();
	    try(Connection con=getCon();
	    		PreparedStatement ps = con.prepareStatement(GETALLINFO)){
	    	  ResultSet rs= ps.executeQuery();
	    	  while(rs.next()) {
	    		    int employee_id= rs.getInt("employee_id");
	    		    String name = rs.getString("name");
					String  job_title= rs.getString(" job_title");
					String department = rs.getString("department");
					String contact_details = rs.getString("contact_details");
	    		 allEmployee.add(new Employee(employee_id,name,job_title,department,contact_details));
	    	  }
	    } catch (SQLException e) {
			
			e.printStackTrace();
		}
		return allEmployee;
	}

	@Override
	public void insertEmployee(Employee employee) {
		try(Connection con=getCon();
				PreparedStatement  ps= con.prepareStatement(INSERTINFO);){
			
			String name=employee.getName();
			String job_title=employee.getJob_title();
			String department= employee.getDepartment();
			String contact_details= employee.getContact_details();
			
			ps.setString(1,name);
			ps.setString(2,job_title);
			ps.setString(3,department);
			ps.setString(4,contact_details);
			ps.executeUpdate();
					
			
		} catch (SQLException e) {e.printStackTrace();}	
	}
		


	@Override
	public void deleteEmployee(int employee_id) {
		try(Connection con=getCon();
				PreparedStatement  ps= con.prepareStatement(DELETEINFO);){
			
			ps.setInt(1, employee_id);
			ps.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
	}
		


	@Override
	public Employee editEmployee(int employee_id) {
		Employee employee=null;
		try(Connection con = getCon();
				PreparedStatement ps= con.prepareStatement(EDITBYID)){
			
			ps.setInt(1,employee_id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				String name = rs.getString("name");
				String  job_title= rs.getString(" job_title");
				String department = rs.getString("department");
				String contact_details = rs.getString("contact_details");
				employee= new Employee(employee_id,name,job_title,department,contact_details);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	
	
	@Override
	public void updateEmployee(Employee employee) {	
			try(Connection con = getCon();
					PreparedStatement ps= con.prepareStatement(UPDATEINFO)){
				 ps.setString(1, employee.getName());
				 ps.setString(2, employee.getJob_title());
				 ps.setString(3, employee.getDepartment());
				 ps.setString(4, employee.getContact_details());
				 ps.setInt(5, employee.getEmployee_id());
				ps.executeUpdate();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
	}
	
	
}	



